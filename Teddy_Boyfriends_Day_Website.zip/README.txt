# Teddy's Boyfriend's Day Website 🧸💙

## What's included
- Baby-blue teddy-bear theme
- Personalized names: Teddy + Raichu
- Love letter
- 10 uploaded photos
- Reasons I Love You section
- Interactive relationship quiz
- Secret surprise button
- Floating hearts
- Optional music button
- Mobile-friendly layout

## How to use it
1. Open `index.html` in a browser to preview the site.
2. Optional: put your own song in this folder and name it `music.mp3`.
3. To publish free, create a GitHub repository, upload `index.html` and the `photos` folder (and `music.mp3` if you have one), then enable GitHub Pages in the repository's Settings > Pages.
4. Send Teddy the GitHub Pages link.

Tip: If you want to change the love letter, open `index.html` in a text editor and edit the text inside the section titled "A Letter For My Teddy".
